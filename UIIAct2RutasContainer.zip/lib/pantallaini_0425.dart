//PantallaIni_0425

import 'package:flutter/material.dart';

class PantallaIni_0425 extends StatelessWidget {
  const PantallaIni_0425({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Pagina Inicial Acevedo 0425"),
        backgroundColor: Color(0xFFE0F7FA),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            ElevatedButton(
              style:
                  ElevatedButton.styleFrom(backgroundColor: Color(0xFFB2EBF2)),
              onPressed: () {
                Navigator.pushNamed(context, '/Pantalla1_0425');
              },
              child: Text("Aterrizando P1",
                  style: TextStyle(color: Color(0xff000000))),
            ),
            ElevatedButton(
              style:
                  ElevatedButton.styleFrom(backgroundColor: Color(0xFF80DEEA)),
              onPressed: () {
                Navigator.pushNamed(context, '/Pantalla2_0425');
              },
              child: Text("Aterrizando P2",
                  style: TextStyle(color: Color(0xff000000))),
            ),
            ElevatedButton(
              style:
                  ElevatedButton.styleFrom(backgroundColor: Color(0xFF4DD0E1)),
              onPressed: () {
                Navigator.pushNamed(context, '/Pantalla3_0425');
              },
              child: Text("Aterrizando P3",
                  style: TextStyle(color: Color(0xff000000))),
            ),
            ElevatedButton(
              style:
                  ElevatedButton.styleFrom(backgroundColor: Color(0xFF26C6DA)),
              onPressed: () {
                Navigator.pushNamed(context, '/Pantalla4_0425');
              },
              child: Text("Aterrizando P4",
                  style: TextStyle(color: Color(0xff000000))),
            ),
            ElevatedButton(
              style:
                  ElevatedButton.styleFrom(backgroundColor: Color(0xFF00BCD4)),
              onPressed: () {
                Navigator.pushNamed(context, '/Pantalla5_0425');
              },
              child: Text("Aterrizando P5",
                  style: TextStyle(color: Color(0xff000000))),
            ),
          ], // fin de nino
        ),
      ),
    );
  } //fin widgets
} //fin app
