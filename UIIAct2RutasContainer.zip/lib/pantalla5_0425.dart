//Pantalla2_0425

import 'package:flutter/material.dart';

class Pantalla5_0425 extends StatelessWidget {
  const Pantalla5_0425({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Pantalla 2 0425"),
        backgroundColor: Color(0xFF00BCD4),
      ),
      body: Center(
        child: Text("Pantalla 2"),
      ),
    );
  }
}
