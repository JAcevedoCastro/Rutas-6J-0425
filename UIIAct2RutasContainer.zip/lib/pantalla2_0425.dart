//Pantalla2_0425

import 'package:flutter/material.dart';

class Pantalla2_0425 extends StatelessWidget {
  const Pantalla2_0425({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("0425"),
        backgroundColor: Color(0xFF80DEEA),
      ),
      body: Center(
          child: Column(
        children: [
          Container(
            height: 130,
            width: double.infinity,
            decoration: BoxDecoration(
              color: Color(0xFF80DEEA),
              borderRadius: BorderRadius.only(
                bottomRight: Radius.circular(50),
                bottomLeft: Radius.circular(50),
              ),
              boxShadow: [
                BoxShadow(
                  color: Color(0xAA6EB1E6),
                  offset: Offset(9, 9),
                  blurRadius: 6,
                ),
              ],
            ),
            alignment: Alignment.center,
            child: Text(
              'I am a header',
              style: TextStyle(
                fontSize: 38,
                color: Colors.white,
              ),
            ),
          ),
          Text(
            "Jonathan Ivan Acevedo Castro 21308051280425",
            style: TextStyle(fontSize: 25),
          )
        ],
      )),
    );
  }
}
