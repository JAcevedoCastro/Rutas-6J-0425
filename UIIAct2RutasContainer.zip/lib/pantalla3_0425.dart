//Pantalla3_0425

import 'package:flutter/material.dart';

class Pantalla3_0425 extends StatelessWidget {
  const Pantalla3_0425({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Pantalla 2 0425"),
        backgroundColor: Color(0xFF4DD0E1),
      ),
      body: Center(
        child: Text("Pantalla 2"),
      ),
    );
  }
}
