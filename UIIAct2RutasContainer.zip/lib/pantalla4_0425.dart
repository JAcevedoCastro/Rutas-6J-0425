//Pantalla2_0425

import 'package:flutter/material.dart';

class Pantalla4_0425 extends StatelessWidget {
  const Pantalla4_0425({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Pantalla 2 0425"),
        backgroundColor: Color(0xFF26C6DA),
      ),
      body: Center(
        child: Text("Pantalla 2"),
      ),
    );
  }
}
