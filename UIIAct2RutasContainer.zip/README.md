# p13-PageRouter-0425

A new Flutter project created with FlutLab - https://flutlab.io

## Getting Started

A few resources to get you started if this is your first Flutter project:

- https://flutter.dev/docs/get-started/codelab
- https://flutter.dev/docs/cookbook

For help getting started with Flutter, view our
https://flutter.dev/docs, which offers tutorials,
samples, guidance on mobile development, and a full API reference.

## Getting Started: FlutLab - Flutter Online IDE

- How to use FlutLab? Please, view our https://flutlab.io/docs
- Join the discussion and conversation on https://flutlab.io/residents
## Trabajo Rutas
![image](https://github.com/JAcevedoCastro/Rutas-6J-0425/assets/144373213/4d4c03a4-301a-4462-9d5f-c05ae7f69dca)
![image](https://github.com/JAcevedoCastro/Rutas-6J-0425/assets/144373213/29ef56d3-6987-4d7f-ad95-245df827b155)
![image](https://github.com/JAcevedoCastro/Rutas-6J-0425/assets/144373213/63af2e00-0774-42c6-9f02-bf5ef2436353)


